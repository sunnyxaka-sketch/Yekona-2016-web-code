# Netlify Site

This site is ready to be deployed to Netlify!

## Deployment Instructions

1. Drag and drop this folder to Netlify's deploy interface at https://app.netlify.com/drop
2. Or use the Netlify CLI:
   ```
   netlify deploy --prod
   ```

## File Structure

- `index.html` - Main HTML file
- `css/styles.css` - Extracted CSS styles
- `js/main.js` - Extracted JavaScript
- `netlify.toml` - Netlify configuration

Generated with HTML to Netlify Converter
